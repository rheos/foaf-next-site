export default function Footer() {
    return (
      <footer>
        <p>© {new Date().getFullYear()} FOAF Foundation</p>
      </footer>
    );
  }
  