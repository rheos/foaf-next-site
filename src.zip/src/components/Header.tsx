export default function Header() {
    return (
      <header>
        <h1>FOAF Foundation</h1>
        <p>Resilient Local Trade – Powered by Trust, Not Cash</p>
      </header>
    );
  }
  