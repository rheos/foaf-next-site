/** @type {import('next').NextConfig} */
const nextConfig = {
  // Add any config options you need here
};

module.exports = nextConfig;
